<?php
/**
 * @file
 * A cached plugin object that tests inheritance including.
 */

class ctoolsNotCachedPluginArray extends ctoolsNotCachedPluginArray2 {}
